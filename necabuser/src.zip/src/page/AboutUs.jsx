import React from 'react';
import AboutBanner from "../component/AboutBanner";
import AboutContent from '../component/AboutContent';
import Journey from '../component/Journey';

export const AboutUs = () => {
  return (
    <div>
        <AboutBanner/>
        {/* <AboutContent/> */}
        <Journey/>
    </div>
  )
}
