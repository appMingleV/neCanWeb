import React from 'react'
import ContactUs from '../component/ContactUs'

const Contact = () => {
  return (
    <div>
      <ContactUs/>
    </div>
  )
}

export default Contact