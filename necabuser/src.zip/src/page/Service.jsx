import React from 'react'
import ServiceBanner from '../component/ServiceBanner';
import Services from '../component/Services'

const Service = () => {
  return (
    <div>
        <ServiceBanner/>
        <Services/>
    </div>
  )
}

export default Service